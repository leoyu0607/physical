var _isEPub = false;
var _isApp = false;
